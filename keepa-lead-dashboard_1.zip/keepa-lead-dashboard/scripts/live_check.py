"""Live smoke test — run once on your laptop or Railway shell before the first real run.

    export KEEPA_API_KEY=...  ANTHROPIC_API_KEY=...   (ANTHROPIC_WORKSPACE_ID=... if needed)
    python scripts/live_check.py

Costs roughly 15 Keepa tokens and one small Claude call (a few searches).
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from leadfinder import profit as P  # noqa: E402
from leadfinder.keepa_client import KeepaClient, build_selection, parse_product  # noqa: E402
from leadfinder.sourcing import WebSourcer  # noqa: E402

ok = True
k = KeepaClient(os.environ.get("KEEPA_API_KEY", ""))
print("1) Keepa tokens:", k.token_status())

sel = build_selection({"category_id": 79903031, "bsr_min": 600, "bsr_max": 50000, "bb_drop90_max": 5,
                       "offers_min": 3, "offers_max": 17, "fbm_zero": True})
asins, total = k.find_products(sel, 50)
print(f"2) Finder, Run 5 DIY filters: {total} matches (Keepa web UI gave 273 on 26 Sep 2026)")
if not 150 <= total <= 450:
    ok = False
    print("   ⚠️ Count is far from 273 — a field name probably differs. Compare with Keepa's 'Show API query'.")
sel_no_fbm = dict(sel)
sel_no_fbm.pop("current_COUNT_NEW_FBM_gte", None)
sel_no_fbm.pop("current_COUNT_NEW_FBM_lte", None)
_, total2 = k.find_products(sel_no_fbm, 50)
print(f"   same without FBM=0 filter: {total2} (should be larger if the FBM filter is being applied)")
if total2 <= total:
    ok = False
    print("   ⚠️ FBM filter seems to be ignored — use the JSON from Keepa's 'Show API query'.")

prods = [parse_product(p) for p in k.get_products(["B002OHN50Y", "B006PFYMLM"])]
for l in prods:
    print(f"3) {l['asin']}: BB £{l['buybox']} · FBA £{l['fba_fee']} · ref {l['referral_pct']}% · BSR {l['bsr']} · "
          f"EAN {l['ean']}")
    if not (l["buybox"] and l["fba_fee"] and l["referral_pct"]):
        ok = False
        print("   ⚠️ missing Buy Box / FBA / referral data")
c = P.calculate(prods[0]["buybox"], 118.61 / 20, "inc", prods[0]["fba_fee"], prods[0]["referral_pct"])
print(f"   3M 50mm @ £5.93: profit £{c['profit']} / ROI {c['roi_pct']}%  (Run 5: £0.35 / 5.9% at BB £11.46)")

if os.environ.get("ANTHROPIC_API_KEY"):
    ws = WebSourcer(os.environ["ANTHROPIC_API_KEY"], os.environ.get("CLAUDE_MODEL", "claude-sonnet-4-5"),
                    searches_per_batch=4, fetches_per_batch=3)
    r = ws.source_batch([prods[1]])
    print("4) Claude agent:", r[prods[1]["asin"]], f"· searches {ws.searches_used}, fetches {ws.fetches_used}")
else:
    print("4) ANTHROPIC_API_KEY not set — skipped agent test")

print("\nALL GOOD ✅" if ok else "\nCHECK THE ⚠️ LINES ABOVE")
