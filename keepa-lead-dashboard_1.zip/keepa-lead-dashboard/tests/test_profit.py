from leadfinder import profit as P


def test_matches_run5_3m_tape_corrected():
    # Run 5: 3M 3434 50mm, BB £11.46, box of 20 @ £118.61 inc VAT, FBA £2.69, referral 12.97%
    r = P.calculate(11.46, 118.61 / 20, "inc", 2.69, 12.97)
    assert r["profit"] == 0.35
    assert r["roi_pct"] == 5.9


def test_matches_run5_everbuild():
    r = P.calculate(8.20, 2.51, "inc", 2.74, 13.05)
    assert r["profit"] == 0.87
    assert r["roi_pct"] == 34.7


def test_ex_vat_grossed_up_like_profit_engine():
    # profit_engine docstring example: sell £12.90, Qogita £1.11 ex VAT
    r = P.calculate(12.90, 1.11, "ex", 2.70, None, ["Health & Personal Care"], referral_mode="engine")
    assert r["cost_inc_vat"] == 1.33
    assert r["referral_pct_used"] == 15.0
    # same maths as profit_engine.calculate (vat on fees cancels out)
    cost = 1.11 * 1.2
    fees = 12.90 * 0.15 + 2.70 + round(12.90 * 0.007, 2)
    vat_on_fees = round(fees * 0.2, 2)
    vat_due = 12.90 / 6 - cost / 6 - vat_on_fees
    engine_profit = 12.90 - cost - fees - vat_on_fees - vat_due
    assert abs(r["profit"] - round(engine_profit, 2)) < 0.011


def test_engine_referral_rule():
    assert P.engine_referral_pct(9.99, ["Beauty"]) == 0.08
    assert P.engine_referral_pct(10.01, ["Beauty"]) == 0.15
    assert P.engine_referral_pct(5, ["DIY & Tools"]) == 0.15


def test_min_referral_and_unknown_vat():
    r = P.calculate(1.50, 0.50, "unknown", 1.0, 8.0)
    assert r["referral_fee"] == 0.30
    r2 = P.calculate(20, 10, "unknown", 3, 15, unknown_vat_as="ex")
    assert r2["cost_inc_vat"] == 12.0


def test_missing_inputs_return_none():
    assert P.calculate(None, 5, "inc", 2, 15) is None
    assert P.calculate(10, 5, "inc", None, 15) is None
