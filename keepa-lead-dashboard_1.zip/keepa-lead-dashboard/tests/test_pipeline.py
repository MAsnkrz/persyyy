"""End-to-end pipeline run with a fake Keepa API and a fake Claude client (no network)."""
import json
import os
import tempfile
from types import SimpleNamespace

import pytest

os.environ.setdefault("DATA_DIR", tempfile.mkdtemp())

from leadfinder import pipeline, sourcing  # noqa: E402
from leadfinder.keepa_client import build_selection, parse_product  # noqa: E402
from leadfinder.storage import Store  # noqa: E402


def keepa_product(asin, ean, title, bb_pence, fba_pence, ref, bsr=5000, items=1, avg90=None):
    cur = [-1] * 40
    cur[3] = bsr
    cur[11] = 5
    cur[18] = bb_pence
    avg = [-1] * 40
    avg[18] = avg90 or bb_pence
    return {"asin": asin, "title": title, "brand": title.split()[0], "eanList": [ean],
            "monthlySold": 100, "fbaFees": {"pickAndPackFee": fba_pence}, "referralFeePercent": ref,
            "numberOfItems": items, "categoryTree": [{"name": "DIY & Tools"}],
            "stats": {"current": cur, "avg90": avg}}


PRODUCTS = [
    keepa_product("B000000001", "5010027797765", "3M 3434 Blue Tape 50mm", 1146, 269, 12.97),
    keepa_product("B000000002", "0610708898399", "Everbuild Backer Rod 10mm", 820, 274, 13.05),
    keepa_product("B000000003", "1111111111111", "Acme Widget Pack of 2", 2000, 300, 15.0, items=2),
    keepa_product("B000000004", "2222222222222", "Nobody Sells This", 1500, 300, 15.0),
    keepa_product("B000000005", "3333333333333", "Volatile Thing", 3000, 300, 15.0, avg90=2000),
]


class FakeResp:
    def __init__(self, status, data):
        self.status_code, self._d, self.text = status, data, json.dumps(data)

    def json(self):
        return self._d


class FakeKeepaSession:
    def __init__(self):
        self.calls = []

    def request(self, method, url, params=None, json=None, timeout=None):
        self.calls.append((url, params))
        if url.endswith("/query"):
            sel = __import__("json").loads(params["selection"])
            assert sel["rootCategory"] == [79903031]
            return FakeResp(200, {"asinList": [p["asin"] for p in PRODUCTS], "totalResults": 5, "tokensLeft": 900})
        if url.endswith("/product"):
            asins = params["asin"].split(",")
            return FakeResp(200, {"products": [p for p in PRODUCTS if p["asin"] in asins], "tokensLeft": 880})
        raise AssertionError(url)


class FakeClaude:
    """Mimics anthropic client.messages.create with a JSON answer."""
    def __init__(self):
        self.messages = self

    def create(self, **kw):
        prompt = kw["messages"][0]["content"]
        assert kw["tools"][0]["type"] == "web_search_20250305"
        assert "amazon.co.uk" in kw["tools"][0]["blocked_domains"]
        answers = {
            "B000000002": {"found": True, "site": "Sealants Direct", "url": "https://x", "price": 2.51, "vat": "inc",
                           "pack_match": "yes", "confidence": "high", "notes": "10m roll matches"},
            "B000000003": {"found": True, "site": "Acme Shop", "url": "https://y", "price": 4.00, "vat": "inc",
                           "pack_match": "no", "confidence": "medium", "notes": "single only"},
            "B000000004": {"found": False, "site": "", "url": "", "price": None, "vat": "unknown",
                           "pack_match": "unsure", "confidence": "na", "notes": "private label"},
            "B000000005": {"found": True, "site": "Vol Ltd", "url": "https://z", "price": 15.0, "vat": "inc",
                           "pack_match": "yes", "confidence": "high", "notes": "exact"},
        }
        out = [dict(asin=a, **v) for a, v in answers.items() if a in prompt]
        return SimpleNamespace(stop_reason="end_turn", content=[SimpleNamespace(type="text", text=json.dumps(out))],
                               usage=SimpleNamespace(input_tokens=100, output_tokens=50,
                                                     server_tool_use=SimpleNamespace(web_search_requests=3,
                                                                                     web_fetch_requests=1)))


def test_parse_and_selection():
    l = parse_product(PRODUCTS[0])
    assert l["buybox"] == 11.46 and l["fba_fee"] == 2.69 and l["bsr"] == 5000 and l["referral_pct"] == 12.97
    sel = build_selection({"category_id": 79903031, "bsr_min": 600, "bsr_max": 50000, "bb_drop90_max": 5,
                           "offers_min": 3, "offers_max": 17, "fbm_zero": True, "monthly_sold_min": 50})
    assert sel["current_SALES_gte"] == 600 and sel["totalOfferCount_lte"] == 17
    assert sel["current_COUNT_NEW_FBM_lte"] == 0 and sel["monthlySold_gte"] == 50


def test_full_run(monkeypatch):
    fake_keepa = FakeKeepaSession()
    import leadfinder.keepa_client as kc
    orig = kc.KeepaClient.__init__

    def init(self, api_key, domain=2, log=print, session=None):
        orig(self, api_key, domain, log, fake_keepa)
    monkeypatch.setattr(kc.KeepaClient, "__init__", init)
    orig_ws = sourcing.WebSourcer.__init__

    def ws_init(self, api_key, model, *a, **k):
        k["client"] = FakeClaude()
        orig_ws(self, api_key, model, *a, **k)
    monkeypatch.setattr(sourcing.WebSourcer, "__init__", ws_init)

    # supplier catalogue with the 3M tape (ex VAT, like a trade list)
    sourcing.save_catalogue("morelli.csv", b"EAN,Price,Title,Pack\n5010027797765,4.9417,3M 3434 50mm,1 (box 20)\n",
                            prices_ex_vat=True)

    store = Store()
    params = {**pipeline.DEFAULTS, "category_id": 79903031, "bb_variance_max": 20, "agents": 2, "batch_size": 2}
    job = store.create_job("test", params)
    pipeline.run_job(store, job, {"KEEPA_API_KEY": "k", "ANTHROPIC_API_KEY": "a"})

    j = store.get_job(job)
    assert j["status"] == "done", j.get("error")
    leads = {l["asin"]: l for l in store.get_leads(job)}
    assert leads["B000000001"]["method"] == "catalogue"
    assert leads["B000000001"]["calc"]["cost_inc_vat"] == 5.93
    assert leads["B000000001"]["status"] == "NEAR-MISS"          # £0.35 / 5.9%
    assert leads["B000000001"]["flag"] == "check pack size"       # catalogue had a pack column
    assert leads["B000000002"]["status"] == "NEAR-MISS"          # £0.87 / 34.7%
    assert leads["B000000003"]["status"] == "PACK MISMATCH"
    assert leads["B000000004"]["status"] == "NOT SOURCED"
    assert leads["B000000005"]["status"] == "FAILED BUY BOX VARIANCE"  # 50% above 90d avg, ROI < 50
    assert j["summary"]["web"]["searches"] == 6                   # 2 batches x 3
    assert j["summary"]["catalogue_matches"] == 1

    from leadfinder.export import to_excel, to_frame
    assert len(to_frame(store.get_leads(job))) == 5
    assert to_excel(store.get_leads(job), j["params"], j["summary"])[:2] == b"PK"


def test_cancel(monkeypatch):
    store = Store()
    job = store.create_job("c", {**pipeline.DEFAULTS, "category_id": 1})
    store.update_job(job, status="cancelling")

    import leadfinder.keepa_client as kc

    def boom(*a, **k):
        raise pipeline.Cancelled()
    monkeypatch.setattr(kc.KeepaClient, "find_products", boom)
    pipeline.run_job(store, job, {"KEEPA_API_KEY": "k"})
    assert store.get_job(job)["status"] == "cancelled"
